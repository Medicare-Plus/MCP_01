# flutter_login

**A sample Flutter project for username/email login and Firebase services with...**
- Email verification
- Password reset
- Parameterized elements

Code for this Medium article with [step-by-step instructions](https://medium.com/@gk_/flutter-classic-login-screen-part-1-of-2-7d4df4dcf98) on how to build this.
[AndroidX compatible.](https://flutter.dev/docs/development/packages-and-plugins/androidx-compatibility)

## Getting Started

For help getting started: [Flutter documentation](https://flutter.io/).

![Flutter](https://cdn.arstechnica.net/wp-content/uploads/2018/12/7-800x272.jpg )